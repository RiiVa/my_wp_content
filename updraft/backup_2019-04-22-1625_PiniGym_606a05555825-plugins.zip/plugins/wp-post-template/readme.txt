=== Post Template ===
Contributors: indianic
Author URI: http://profiles.wordpress.org/indianic
Tags: wp post template, template, post template, custom template, custom post template, theme tempalte, custom theme template, wordpress post template, post templates, Simple Post Templates, custom template for post.
Requires at least: 3.0
Tested up to: 3.4.2
Stable tag: trunk
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Get the Beauty of Your Webpages  in Your Posts Too

== Description ==

WordPress allows users to customize templates for webpages but, it is not so for blog posts. Post Template plug-in from IndiaNIC enables you to use the customized page templates for your blog posts also.

As soon as you install the Post Template plug-in, it appears on the sidebar of your page. You can choose your desired template from the drop-down button and then you can view your posts in that template.

If you want to know more about how to create your own page templates, then you can visit the link <a href="http://codex.wordpress.org/Pages#Creating_Your_Own_Page_Templates" target="_blank">How to Create Page Templates</a>


<a href="http://www.indianic.com/" target="_blank"><strong>Visit Our Website</strong></a>


== Installation ==

1. Upload the 'wp-post-template' folder to the /wp-content/plugins directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.

== Frequently Asked Questions ==

Have a question? Email me at submission@indianic.com


== Screenshots ==

1. screenshot-1.png


== Developers ==

If you want to implement the *custom post templates* on a *custom post type*, you can use the *cpt_post_types* filter, here's an example below of adding the custom post template selector and metabox to the Movie and Actor custom post types. This code can be added to a plugin or to the *functions.php* file in your theme.


== Changelog ==

= 1.0 =
* Install Plugin


== Upgrade Notice ==

= 1.0 =
* No currently update found.