<?php
/**
 * Handle the torbara WP Customize workflow.
 *
 * @ignore
 *
 * @package API\WP_Customize
 */
final class yourfitness_tt_WP_Customize {

	/**
	 * Fields section.
	 *
	 * @type string
	 */
	private $section;


	/**
	 * Constructor.
	 */
	public function __construct( $section, $args ) {

		$defaults = array(
			'title' => esc_html__( 'Undefined', 'your-fitness' ),
			'priority' => 30,
			'description' => false
		);

		$this->section = $section;
		$this->args = array_merge( $defaults, $args );

		// Add section, settings and controls.
		$this->add();

		yourfitness_add_attribute( 'yourfitness_field_label', 'class', 'customize-control-title' );

	}


	/**
	 * Add section, settings and controls.
	 */
	private function add() {

		global $wp_customize;

		$this->add_section( $wp_customize );

		$fields = yourfitness_get_fields( 'wp_customize', $this->section );

		foreach ( $fields as $field ) {

			if ( $field['type'] === 'group' )
				foreach ( $field['fields'] as $_field )
					$this->add_setting( $wp_customize, $_field );

			$this->add_setting( $wp_customize, $field );
			$this->add_control( $wp_customize, $field );

		}

	}


	/**
	 * Add Section.
	 */
	private function add_section( $wp_customize ) {

		if ( $wp_customize->get_section( $this->section ) )
			return;

		$wp_customize->add_section(
			$this->section,
			array(
				'title' => $this->args['title'],
				'priority' => $this->args['priority'],
				'description' => $this->args['description'],
			)
		);

	}


	/**
	 * Add setting.
	 */
	private function add_setting( $wp_customize, $field ) {

		$defaults = array(
			'db_type' => 'theme_mod',
			'capability' => 'edit_theme_options',
			'transport' => 'postMessage',
		);

		$field = array_merge( $defaults, $field );

		$wp_customize->add_setting(
			$field['name'],
			array(
				'default' => yourfitness_get( 'default', $field ),
				'type' => $field['db_type'],
				'capability' => $field['capability'],
				'transport' => $field['transport'],
				'sanitize_callback' => array( $this, 'sanitize' )
			)
		);

	}


	/**
	 * Add Control.
	 */
	private function add_control( $wp_customize, $field ) {

		$class = 'yourfitness_tt_WP_Customize_Control';

		if ( $field['type'] !== $class && class_exists( $field['type'] ) )
			$class = $field['type'];

		$wp_customize->add_control(
			new $class(
				$wp_customize,
				$field['name'],
				array(
					'label' => $field['label'],
					'section' => $this->section
				),
				$field
			)
		);

	}


	/**
	 * Sanatize value.
	 */
	public function sanitize( $value ) {

		return $value;

	}

}


if ( class_exists( 'WP_Customize_Control' ) ) :

	/**
	 * Render torbara fields content for WP Customize.
	 *
	 * @ignore
	 */
	class yourfitness_tt_WP_Customize_Control extends WP_Customize_Control {

		/**
		 * Field data.
		 *
		 * @type string
		 */
		private $yourfitness_field;


		/**
		 * Constructor.
		 */
		public function __construct() {

			$args = func_get_args();

			call_user_func_array( array( 'parent', '__construct' ), $args );

			$this->yourfitness_field = end( $args );

		}


		/**
		 * Field content.
		 */
		public function render_content() {

			yourfitness_field( $this->yourfitness_field );

		}

	}

endif;